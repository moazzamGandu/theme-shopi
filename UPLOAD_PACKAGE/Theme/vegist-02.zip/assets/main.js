(function ($) {
  "use strict";
  jQuery(document).ready(function(){
    var windows = $(window);
    var sticky = $('.header-sticky');
    windows.on('scroll', function() {
      var scroll = windows.scrollTop();
      if (scroll < 100) {
        sticky.removeClass('is-sticky');
      }else{
        sticky.addClass('is-sticky');
      }
    });
    $("button.navbar-toggler").click(function(){
      $(".main-menu-area").addClass("active");
      $(".mm-fullscreen-bg").addClass("active");
      $("body").addClass("hidden");
    });
    $(".close-box").click(function(){
      $(".main-menu-area").removeClass("active");
      $(".mm-fullscreen-bg").removeClass("active");
      $("body").removeClass("hidden");
    });
    $(".mm-fullscreen-bg").click(function(){
      $(".main-menu-area").removeClass("active");
      $(".mm-fullscreen-bg").removeClass("active");
      $("body").removeClass("hidden");
    });
    $(".mm-fullscreen-bg").click(function(){
      $(".mm-fullscreen-bg").removeClass("active");
    $(".filter-sidebar").removeClass("active");
    });
    $("button.filter-button").on('click', function() {
      $(".filter-sidebar").addClass("active");
      $(".mm-fullscreen-bg").addClass("active");
    });
    $("button.close-filter-sidebar").on('click', function() {
      $(".filter-sidebar").removeClass("active");
      $(".mm-fullscreen-bg").removeClass("active");
    });
    $('.full-view, .zoom').on('click', function() {
      $('.product_img_top').magnificPopup({
        delegate: 'a',
        type:'image',
        showCloseBtn: true,
        closeBtnInside: false,
        midClick: true,
        tLoading: 'Loading image #%curr%...',
        mainClass: 'mfp-img-mobile',
        gallery: {
          enabled: true,
          navigateByImgClick: true,
          preload: [0,1]
        }
      }).magnificPopup('open');
    });
    $(window).scroll(function(){
      if ($(this).scrollTop() > 1000) {
        $('#top').fadeIn();
      } else {
        $('#top').fadeOut();
      }
    });
    $('#top').click(function(){
      $("html, body").animate({ scrollTop: 0 }, 100);
      return false;
    });
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl)
    })
  });
})(jQuery);